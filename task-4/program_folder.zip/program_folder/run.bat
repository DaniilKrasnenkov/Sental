@echo off
java -jar "%~dp0program.jar"
pause